require("dotenv").config();
const express = require("express");
const cookieParser = require("cookie-parser");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

let Razorpay = null;
try { Razorpay = require("razorpay"); } catch {}

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DB_DIR = path.join(ROOT, "data");
const UPLOAD_DIR = path.join(ROOT, "uploads");
fs.mkdirSync(DB_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(ROOT, "public")));
app.use("/uploads", express.static(UPLOAD_DIR));

const db = new Database(path.join(DB_DIR, "brandnew.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS products(
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT NOT NULL,
 price INTEGER NOT NULL, old_price INTEGER DEFAULT 0, tag TEXT DEFAULT 'New',
 description TEXT DEFAULT '', sizes TEXT DEFAULT 'S,M,L,XL', colors TEXT DEFAULT 'Black',
 stock INTEGER DEFAULT 0, image TEXT DEFAULT '', active INTEGER DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders(
 id INTEGER PRIMARY KEY AUTOINCREMENT, order_code TEXT UNIQUE NOT NULL, customer_name TEXT NOT NULL,
 phone TEXT NOT NULL, email TEXT DEFAULT '', address TEXT NOT NULL, items_json TEXT NOT NULL,
 total INTEGER NOT NULL, payment_method TEXT NOT NULL, payment_status TEXT DEFAULT 'pending',
 status TEXT DEFAULT 'Order placed', gateway_order_id TEXT DEFAULT '', gateway_payment_id TEXT DEFAULT '',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

const adminEmail = process.env.ADMIN_EMAIL || "admin@brandnew.store";
const adminPassword = process.env.ADMIN_PASSWORD || "ChangeThisPassword123!";
if (!db.prepare("SELECT id FROM admins WHERE email=?").get(adminEmail)) {
  db.prepare("INSERT INTO admins(email,password_hash) VALUES(?,?)").run(adminEmail, bcrypt.hashSync(adminPassword, 12));
}
if (db.prepare("SELECT COUNT(*) c FROM products").get().c === 0) {
  const add = db.prepare(`INSERT INTO products(name,category,price,old_price,tag,description,sizes,colors,stock,image) VALUES(?,?,?,?,?,?,?,?,?,?)`);
  [
    ["Essential Oversized T-Shirt","T-Shirts",799,999,"Bestseller","Heavyweight cotton everyday tee","S,M,L,XL","Black,White,Olive",30,""],
    ["Relaxed Fit Denim","Jeans",1699,1999,"Trending","Premium relaxed denim with clean wash","30,32,34,36,38","Blue,Black",20,""],
    ["Oxford Premium Shirt","Shirts",1299,1599,"New","Crisp Oxford shirt for smart casual looks","S,M,L,XL","White,Sky Blue,Black",25,""],
    ["Leather Signature Jacket","Jackets",3499,4299,"Premium","Statement winter layer with premium finish","M,L,XL,XXL","Black,Brown",12,""],
    ["Heavyweight Pullover Hoodie","Hoodies",1899,2299,"Winter","Warm heavyweight fleece hoodie","S,M,L,XL","Black,Grey,Cream",18,""],
    ["Puffer Winter Jacket","Winterwear",2999,3499,"Winter","Warm puffer for cold days","M,L,XL,XXL","Black,Navy",10,""],
    ["Cargo Street Pant","Pants",1499,1799,"Trending","Relaxed utility cargo silhouette","30,32,34,36,38","Black,Olive,Beige",22,""],
    ["Textured Knit Sweater","Winterwear",1799,2199,"New","Soft textured knit layer","S,M,L,XL","Cream,Grey,Black",16,""]
  ].forEach(x=>add.run(...x));
}

const upload = multer({
  storage: multer.diskStorage({
    destination: (_,__,cb)=>cb(null,UPLOAD_DIR),
    filename: (_,file,cb)=>cb(null,Date.now()+"-"+file.originalname.replace(/[^a-zA-Z0-9._-]/g,"_"))
  }),
  limits:{fileSize:5*1024*1024},
  fileFilter:(_,file,cb)=>cb(null,/^image\/(jpeg|png|webp)$/.test(file.mimetype))
});

function auth(req,res,next){
  try {
    const token=req.cookies.bn_admin;
    if(!token) return res.status(401).json({error:"Login required"});
    req.admin=jwt.verify(token, process.env.JWT_SECRET || "dev-only-change-me");
    next();
  } catch { res.status(401).json({error:"Login required"}); }
}
function code(){ return "BN"+Date.now().toString().slice(-8)+Math.floor(10+Math.random()*90); }

app.get("/api/store",(req,res)=>{
  const products=db.prepare("SELECT * FROM products WHERE active=1 ORDER BY id DESC").all()
    .map(p=>({...p,sizes:p.sizes.split(",").filter(Boolean),colors:p.colors.split(",").filter(Boolean)}));
  res.json({store:process.env.STORE_NAME||"BRAND NEW",upi:process.env.STORE_UPI_ID||"",qr:"/assets/payment-qr.png",products});
});

app.post("/api/admin/login",(req,res)=>{
  const {email,password}=req.body||{};
  const a=db.prepare("SELECT * FROM admins WHERE email=?").get(email);
  if(!a || !bcrypt.compareSync(password||"",a.password_hash)) return res.status(401).json({error:"Invalid email or password"});
  const token=jwt.sign({id:a.id,email:a.email},process.env.JWT_SECRET||"dev-only-change-me",{expiresIn:"8h"});
  res.cookie("bn_admin",token,{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:8*60*60*1000});
  res.json({ok:true});
});
app.post("/api/admin/logout",(req,res)=>{res.clearCookie("bn_admin");res.json({ok:true})});
app.get("/api/admin/me",auth,(req,res)=>res.json({email:req.admin.email}));

app.get("/api/admin/products",auth,(req,res)=>res.json(db.prepare("SELECT * FROM products ORDER BY id DESC").all()));
app.post("/api/admin/products",auth,upload.single("image"),(req,res)=>{
  const b=req.body;
  const image=req.file?"/uploads/"+req.file.filename:(b.image||"");
  const r=db.prepare(`INSERT INTO products(name,category,price,old_price,tag,description,sizes,colors,stock,image) VALUES(?,?,?,?,?,?,?,?,?,?)`)
    .run(b.name,b.category,Number(b.price),Number(b.old_price||0),b.tag||"New",b.description||"",b.sizes||"S,M,L,XL",b.colors||"Black",Number(b.stock||0),image);
  res.json({id:r.lastInsertRowid});
});
app.put("/api/admin/products/:id",auth,upload.single("image"),(req,res)=>{
  const b=req.body, old=db.prepare("SELECT * FROM products WHERE id=?").get(req.params.id);
  if(!old) return res.status(404).json({error:"Not found"});
  const image=req.file?"/uploads/"+req.file.filename:(b.image!==undefined?b.image:old.image);
  db.prepare(`UPDATE products SET name=?,category=?,price=?,old_price=?,tag=?,description=?,sizes=?,colors=?,stock=?,image=?,active=? WHERE id=?`)
    .run(b.name,b.category,Number(b.price),Number(b.old_price||0),b.tag||"New",b.description||"",b.sizes||"S,M,L,XL",b.colors||"Black",Number(b.stock||0),image,Number(b.active??1),req.params.id);
  res.json({ok:true});
});
app.delete("/api/admin/products/:id",auth,(req,res)=>{db.prepare("DELETE FROM products WHERE id=?").run(req.params.id);res.json({ok:true})});
app.post("/api/admin/trend-price",auth,(req,res)=>{
  const pct=Number(req.body.pct||0);
  db.prepare("UPDATE products SET price=MAX(1,ROUND(price*(1+?/100.0)))").run(pct);
  res.json({ok:true});
});

app.get("/api/admin/orders",auth,(req,res)=>res.json(db.prepare("SELECT * FROM orders ORDER BY id DESC").all()));
app.patch("/api/admin/orders/:id",auth,(req,res)=>{
  const {status,payment_status}=req.body;
  db.prepare("UPDATE orders SET status=COALESCE(?,status), payment_status=COALESCE(?,payment_status) WHERE id=?")
    .run(status||null,payment_status||null,req.params.id);
  res.json({ok:true});
});

app.get("/api/orders/:code",(req,res)=>{
  const o=db.prepare("SELECT order_code,status,payment_status,total,created_at FROM orders WHERE order_code=?").get(req.params.code);
  if(!o)return res.status(404).json({error:"Order not found"});
  res.json(o);
});

app.post("/api/orders",(req,res)=>{
  const b=req.body||{};
  if(!b.name||!b.phone||!b.address||!Array.isArray(b.items)||!b.items.length) return res.status(400).json({error:"Missing checkout details"});
  let total=0; const normalized=[];
  for(const item of b.items){
    const p=db.prepare("SELECT * FROM products WHERE id=? AND active=1").get(item.product_id);
    if(!p)return res.status(400).json({error:"Product unavailable"});
    const qty=Math.max(1,Number(item.qty||1));
    if(p.stock<qty)return res.status(400).json({error:`Only ${p.stock} left for ${p.name}`});
    total+=p.price*qty;
    normalized.push({product_id:p.id,name:p.name,qty,size:item.size||"",color:item.color||"",price:p.price});
  }
  const orderCode=code();
  db.prepare(`INSERT INTO orders(order_code,customer_name,phone,email,address,items_json,total,payment_method) VALUES(?,?,?,?,?,?,?,?)`)
    .run(orderCode,b.name,b.phone,b.email||"",b.address,JSON.stringify(normalized),total,b.payment_method||"UPI_QR");
  for(const x of normalized)db.prepare("UPDATE products SET stock=stock-? WHERE id=?").run(x.qty,x.product_id);

  let gateway=null;
  if((b.payment_method||"") === "RAZORPAY" && Razorpay && process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET){
    const rp=new Razorpay({key_id:process.env.RAZORPAY_KEY_ID,key_secret:process.env.RAZORPAY_KEY_SECRET});
    gateway=awaitPromise(rp.orders.create({amount:total*100,currency:"INR",receipt:orderCode}));
    gateway.then(g=>db.prepare("UPDATE orders SET gateway_order_id=? WHERE order_code=?").run(g.id,orderCode));
  }
  if(gateway) gateway.then(g=>res.json({order_code:orderCode,total,razorpay:{id:g.id,key:process.env.RAZORPAY_KEY_ID}})).catch(()=>res.json({order_code:orderCode,total}));
  else res.json({order_code:orderCode,total});
});

function awaitPromise(p){return Promise.resolve(p)}

app.post("/api/payments/verify",async(req,res)=>{
  const crypto=require("crypto");
  const {order_code,razorpay_order_id,razorpay_payment_id,razorpay_signature}=req.body||{};
  const o=db.prepare("SELECT * FROM orders WHERE order_code=?").get(order_code);
  if(!o || !process.env.RAZORPAY_KEY_SECRET)return res.status(400).json({error:"Payment verification is not configured"});
  const expected=crypto.createHmac("sha256",process.env.RAZORPAY_KEY_SECRET).update(razorpay_order_id+"|"+razorpay_payment_id).digest("hex");
  if(expected!==razorpay_signature)return res.status(400).json({error:"Invalid payment signature"});
  db.prepare("UPDATE orders SET payment_status='paid',gateway_payment_id=? WHERE order_code=?").run(razorpay_payment_id,order_code);
  res.json({ok:true});
});

app.post("/api/payments/webhook",(req,res)=>{
  // Configure RAZORPAY_WEBHOOK_SECRET and verify the raw request body with
  // your gateway's webhook-signature mechanism before changing payment status.
  // This starter deliberately does not trust an unsigned webhook payload.
  if(!process.env.RAZORPAY_WEBHOOK_SECRET)return res.status(503).json({error:"Webhook secret not configured"});
  res.json({received:true});
});

app.listen(PORT,()=>console.log(`BRAND NEW running on http://localhost:${PORT}`));
