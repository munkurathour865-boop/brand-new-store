# BRAND NEW — Premium Clothing Store

Full-stack starter for a premium men's clothing brand.

## Run
1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Change `ADMIN_PASSWORD` and `JWT_SECRET`.
4. Run `npm install`.
5. Run `npm start`.
6. Open `http://localhost:3000`.
7. Admin dashboard: `http://localhost:3000/admin.html`.

## Included
- Premium mobile-first storefront
- T-shirts, jeans, shirts, hoodies, leather jackets and winterwear
- Product variants (size/color)
- Stock management
- Product image upload
- Cart and checkout
- Order IDs and tracking
- Admin login
- Add/edit/delete products
- Bulk trend pricing
- Order status management
- Revenue dashboard
- Supplied QR image at `/assets/payment-qr.png`
- Razorpay-ready server payment flow

## Payments
A QR image is only a payment display; it does not securely prove that a payment happened.
For automatic payment confirmation, connect Razorpay (or another compliant payment gateway) and configure the webhook variables in `.env`.

Never expose the Razorpay secret key in frontend JavaScript.

For production, use HTTPS, a strong secret, a real business UPI/payment gateway, managed database/storage, rate limiting and proper backups.
